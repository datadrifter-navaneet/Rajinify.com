import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { HomePage } from './pages/HomePage';
import { FaceSwapPage } from './pages/FaceSwapPage';
import { Toaster } from 'sonner';

function App() {
  return (
    <BrowserRouter>
      <Toaster position="top-center" richColors />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/swap" element={<FaceSwapPage />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App; 